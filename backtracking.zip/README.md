Julián Rodríguez Sarmiento, 2019047635
Sebastián Ernesto Cruz Guzmán, 2019052049
Angel Zeledón Fernández, 2022211496
Emmanuel Matamoros Jiménez, 2021040420
Valeska Brenes Picado, 2021031484

Readme del Rompecabezas Deslizante

Este es un rompecabezas deslizante implementado en HTML y CSS. El objetivo del rompecabezas es ordenar las piezas deslizantes de la imagen en el tablero para recrear la imagen original. El código proporcionado establece el diseño y la apariencia del rompecabezas.

Estructura del Archivo:

index.html: Contiene la estructura HTML del rompecabezas, incluyendo el tablero y las imágenes deslizantes.
styles.css: Define los estilos y la apariencia del rompecabezas. Incluye reglas para el diseño del tablero, las celdas, y los botones interactivos para el usuario.
Cómo Jugar:

Abre el archivo index.html en tu navegador web.
Observarás una imagen descompuesta en piezas deslizantes en el tablero.
Haz clic en las piezas deslizantes para moverlas al espacio en blanco y reorganizarlas.
Tu objetivo es reorganizar las piezas para recrear la imagen original.

¡Diviértete resolviendo el rompecabezas!
